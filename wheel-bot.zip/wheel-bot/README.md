# Wheel bot

Sells cash-secured puts and covered calls automatically on Alpaca, once every weekday, from GitHub's servers.
Starts in PAPER + DRY_RUN mode. Not financial advice.

## Setup (about 15 minutes)
1. Create a free Alpaca account, open the **Paper Trading** dashboard, and generate API keys.
2. Create a **private** GitHub repository and upload every file in this folder (keep the `.github` folder).
3. In the repo: Settings > Secrets and variables > Actions.
   - Secrets: `ALPACA_API_KEY`, `ALPACA_SECRET_KEY`, and optionally `NTFY_TOPIC`.
   - Variables (optional): `WATCHLIST` (e.g. `SPY,QQQ,IWM`), `DRY_RUN`, `PAPER`, `SELL_PUTS`.
4. Actions tab > Wheel bot > **Run workflow** to test. Read the log output.
5. After a week of sensible dry runs, set variable `DRY_RUN` = `false` (still paper money).
6. Only after months of paper results would you use live keys and set `PAPER` = `false`.

## Phone alerts
Install the free **ntfy** app, subscribe to a long random topic name (e.g. `wheel-8f3k29xq`),
and save the same name as the `NTFY_TOPIC` secret. Anyone who guesses the name can read the alerts,
so make it random.

## Notes
- GitHub scheduled runs can start late on busy days, so the bot checks that the market is open first.
- Private repos get a monthly allowance of free Actions minutes; one short run per weekday uses a small fraction.
- To stop everything instantly: Actions tab > Wheel bot > "..." > Disable workflow.
